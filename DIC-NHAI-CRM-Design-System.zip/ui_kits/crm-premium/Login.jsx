/* Login.jsx — refined NHAI brand surface with React Icon */

function Login({ onSignIn }) {
  const [email,    setEmail]    = React.useState('admin@crm.local');
  const [password, setPassword] = React.useState('admin123');
  const [show,     setShow]     = React.useState(false);

  function submit(e) {
    e.preventDefault();
    onSignIn();
  }

  return (
    <div className="login-screen" data-screen-label="Login">
      <div className="login-left">
        <div className="login-left-inner">
          <div className="login-emblem"><Icon name="route" size={28} strokeWidth={2} /></div>
          <div className="login-org-abbr">DIC — NHAI</div>
          <div className="login-org-full">Digital Infrastructure Command</div>
          <div className="login-org-sub">National Highways Authority of India</div>
          <div className="login-divider"></div>
          <div className="login-tagline">The command centre for India's highway operations.</div>
          <div className="login-blurb">
            Manage accounts, pipeline, projects, and support — across every regional office, in one secure workspace.
          </div>
        </div>
        <div className="login-footer">
          <span>© 2026 DIC — NHAI</span>
          <span>Ministry of Road Transport &amp; Highways</span>
        </div>
      </div>

      <div className="login-right">
        <div className="login-form-wrap">
          <h2 className="login-form-title">Welcome back</h2>
          <p className="login-form-sub">Sign in to your account to continue.</p>

          <form className="login-form" onSubmit={submit}>
            <div className="login-field">
              <label className="login-label">Email</label>
              <div className="login-input-wrap">
                <Icon name="mail" size={16} color="#98a0ad" />
                <input
                  className="login-input"
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="you@nhai.gov.in"
                />
              </div>
            </div>

            <div className="login-field">
              <label className="login-label">Password</label>
              <div className="login-input-wrap">
                <Icon name="lock" size={16} color="#98a0ad" />
                <input
                  className="login-input"
                  type={show ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                />
                <button
                  type="button"
                  onClick={() => setShow(s => !s)}
                  style={{ background: 'none', border: 'none', cursor: 'pointer', display: 'flex', color: '#98a0ad', padding: 0 }}
                >
                  <Icon name={show ? 'eye-off' : 'eye'} size={16} />
                </button>
              </div>
            </div>

            <button className="login-submit" type="submit">Sign in</button>
          </form>

          <div className="login-creds">
            <div className="lbl">Demo credentials</div>
            <code>admin@crm.local</code> / <code>admin123</code>
          </div>
        </div>
      </div>
    </div>
  );
}

window.Login = Login;
