/* Dashboard.jsx — React Icon component + stagger entry animation */

function fmtINR(n) {
  if (n >= 1e7) return '₹' + (n / 1e7).toFixed(2) + 'Cr';
  if (n >= 1e5) return '₹' + (n / 1e5).toFixed(1) + 'L';
  return '₹' + n.toLocaleString('en-IN');
}

function KpiCard({ icon, chip, val, label, delta, deltaTone, index }) {
  return (
    <div className="kpi">
      <div className="kpi-top">
        <div className={'kpi-chip chip-' + chip}>
          <Icon name={icon} size={18} strokeWidth={2} />
        </div>
        {delta && (
          <span className={'kpi-delta delta-' + deltaTone}>
            <Icon name={deltaTone === 'up' ? 'arrow-up-right' : deltaTone === 'down' ? 'arrow-down-right' : 'minus'} size={11} strokeWidth={2.2} />
            {delta}
          </span>
        )}
      </div>
      <div className="kpi-val">{val}</div>
      <div className="kpi-label">{label}</div>
    </div>
  );
}

function PipelineCard({ rows }) {
  const total = rows.reduce((s, r) => s + r.val, 0);
  return (
    <div className="card">
      <div className="card-head">
        <div>
          <h3>Sales pipeline</h3>
          <div className="sub">Lead value by stage · last 30 days</div>
        </div>
        <div className="actions">
          <button className="btn btn-ghost"><Icon name="external-link" />View all</button>
        </div>
      </div>
      <div className="pipeline">
        {rows.map(r => (
          <div key={r.stage} className="pipeline-row">
            <span className="stage"><span className="stage-pin" style={{ background: r.color }}></span>{r.stage}</span>
            <div className="pipeline-bar-bg">
              <div className="pipeline-bar-fill" style={{ width: r.pct + '%', background: r.color }}></div>
            </div>
            <span className="pipeline-val">{fmtINR(r.val)}</span>
          </div>
        ))}
      </div>
      <div className="pipeline-foot">
        <span className="label">Weighted forecast</span>
        <span className="val">{fmtINR(total * 0.42)}</span>
      </div>
    </div>
  );
}

function DonutCard({ rows }) {
  const total = rows.reduce((s, r) => s + r.value, 0);
  const R = 38, C = 2 * Math.PI * R;
  let acc = 0;
  const segments = rows.map(r => {
    const len = (r.value / total) * C;
    const seg = { ...r, dash: `${len} ${C - len}`, off: -acc };
    acc += len;
    return seg;
  });
  return (
    <div className="card">
      <div className="card-head">
        <div>
          <h3>Ticket status</h3>
          <div className="sub">Current distribution</div>
        </div>
      </div>
      <div className="donut-wrap">
        <svg viewBox="0 0 100 100" className="donut-svg">
          <circle cx="50" cy="50" r={R} fill="none" stroke="#f1f2f4" strokeWidth="12" />
          {segments.map(s => (
            <circle
              key={s.label}
              cx="50" cy="50" r={R}
              fill="none" stroke={s.color} strokeWidth="12"
              strokeDasharray={s.dash} strokeDashoffset={s.off}
              transform="rotate(-90 50 50)"
            />
          ))}
          <text x="50" y="48" textAnchor="middle"
            style={{ fontFamily: 'DM Mono, monospace', fontSize: 16, fontWeight: 700, fill: '#0a1628' }}>
            {total}
          </text>
          <text x="50" y="59" textAnchor="middle"
            style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 7, fill: '#98a0ad', letterSpacing: '.08em' }}>
            TOTAL
          </text>
        </svg>
        <div className="donut-legend">
          {rows.map(r => (
            <div key={r.label} className="legend-item">
              <span className="legend-pin" style={{ background: r.color }}></span>
              <span className="name">{r.label}</span>
              <span className="num">{r.value}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function TopAccountsCard({ rows }) {
  return (
    <div className="card">
      <div className="card-head">
        <div>
          <h3>Top accounts</h3>
          <div className="sub">By renewal urgency</div>
        </div>
        <div className="actions"><button className="btn btn-ghost">All</button></div>
      </div>
      <div className="account-list">
        {rows.map(r => (
          <div key={r.name} className="account-item">
            <div className="account-mono">{r.name.split(' ').filter(Boolean).slice(0, 2).map(w => w[0]).join('').slice(0, 2).toUpperCase()}</div>
            <div className="account-info">
              <div className="account-name">{r.name}</div>
              <div className="account-meta">Last touch · 4d</div>
            </div>
            <span className={'account-renewal' + (r.soon ? ' soon' : '')}>{r.renewal}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function ActivityCard({ rows }) {
  const map = { '📞': 'phone', '📧': 'mail', '💰': 'trending-up', '🎫': 'life-buoy', '📁': 'folder-kanban', '👥': 'users' };
  return (
    <div className="card">
      <div className="card-head">
        <div>
          <h3>Recent activity</h3>
          <div className="sub">Across all teams</div>
        </div>
        <div className="actions"><button className="btn btn-ghost">All events</button></div>
      </div>
      <div className="activity">
        {rows.map((r, i) => (
          <div key={i} className="activity-item">
            <div className="activity-icon"><Icon name={map[r.icon] || 'circle'} size={14} /></div>
            <div className="activity-body">
              <div className="activity-text">{r.text}</div>
              <div className="activity-time">{r.time}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function Dashboard({ data }) {
  const today = new Date().toLocaleDateString('en-IN', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' });
  return (
    <section data-screen-label="Dashboard">
      <div className="page-header">
        <div>
          <h1>Good morning, Rajiv</h1>
          <div className="sub">{today} · here's how the pipeline is moving</div>
        </div>
        <div className="page-actions">
          <button className="btn btn-secondary"><Icon name="download" />Export</button>
          <button className="btn btn-primary"><Icon name="plus" />New deal</button>
        </div>
      </div>

      <div className="kpi-row">
        <KpiCard index={0} icon="users"       chip="blue"   val="142"     label="Total contacts"    delta="+8.2%"  deltaTone="up"   />
        <KpiCard index={1} icon="flame"       chip="violet" val="38"      label="Active leads"      delta="+3"     deltaTone="up"   />
        <KpiCard index={2} icon="trending-up" chip="green"  val="₹8.42M"  label="Forecast"          delta="+12.4%" deltaTone="up"   />
        <KpiCard index={3} icon="life-buoy"   chip="amber"  val="9"       label="Open tickets"      delta="-2"     deltaTone="down" />
      </div>

      <div className="grid-row row-2-1">
        <PipelineCard rows={data.pipeline} />
        <DonutCard rows={data.ticketStatus} />
      </div>

      <div className="grid-row row-1-1">
        <TopAccountsCard rows={data.topAccounts} />
        <ActivityCard rows={data.activity} />
      </div>
    </section>
  );
}

window.Dashboard = Dashboard;
