/* Projects.jsx — React Icon component (no DOM mutation) */

function pcardInitials(name) {
  return name.split(/\s+/).filter(Boolean).map(w => w[0]).join('').replace(/\./g, '').slice(0, 2).toUpperCase();
}

function ProjectCard({ project }) {
  const managers = project.manager.split(', ').slice(0, 2);
  return (
    <div className="project-card">
      <div className="pcard-name">{project.name}</div>
      <div className="pcard-meta">
        <Icon name="building-2" size={11} />
        <span>{project.account}</span>
      </div>
      <div className="pcard-progress">
        <div className="pcard-bar-bg">
          <div className="pcard-bar-fill" style={{ width: project.progress + '%' }}></div>
        </div>
        <span className="pcard-pct">{project.progress}%</span>
      </div>
      <div className="pcard-bottom">
        <div className="pcard-avatars">
          {managers.map((m, i) => (
            <span key={i} className="a">{pcardInitials(m)}</span>
          ))}
        </div>
        <span className="pcard-due">{project.due}</span>
      </div>
    </div>
  );
}

function Projects({ data }) {
  const [view, setView] = React.useState('board');

  const cols = [
    { key: 'Planning',  title: 'Planning',  pin: '#ca8a04' },
    { key: 'Active',    title: 'Active',    pin: '#2563eb' },
    { key: 'OnHold',    title: 'On Hold',   pin: '#f97316' },
    { key: 'Completed', title: 'Completed', pin: '#22c55e' },
  ];

  return (
    <section data-screen-label="Projects">
      <div className="page-header">
        <div>
          <h1>Projects</h1>
          <div className="sub">5 active · 1 on hold · 1 completed this quarter</div>
        </div>
        <div className="page-actions">
          <button className="btn btn-secondary"><Icon name="git-branch" />Jira sync</button>
          <button className="btn btn-primary"><Icon name="plus" />New project</button>
        </div>
      </div>

      <div className="kanban-header">
        <div className="view-tabs">
          <button className={'view-tab' + (view === 'board' ? ' active' : '')} onClick={() => setView('board')}><Icon name="kanban-square" size={13} />Board</button>
          <button className={'view-tab' + (view === 'list'  ? ' active' : '')} onClick={() => setView('list')}><Icon name="list" size={13} />List</button>
          <button className={'view-tab' + (view === 'gantt' ? ' active' : '')} onClick={() => setView('gantt')}><Icon name="bar-chart-horizontal" size={13} />Timeline</button>
        </div>
        <button className="btn btn-ghost"><Icon name="sliders-horizontal" />Filters</button>
      </div>

      {view === 'board' && (
        <div className="project-board">
          {cols.map(c => {
            const items = data.projects[c.key] || [];
            return (
              <div key={c.key} className="project-col">
                <div className="project-col-head">
                  <div className="project-col-title">
                    <span style={{ background: c.pin, width: 8, height: 8, borderRadius: '50%', display: 'inline-block' }}></span>
                    {c.title}
                    <span className="project-col-count">{items.length}</span>
                  </div>
                  <button className="project-col-add"><Icon name="plus" size={14} /></button>
                </div>
                <div className="project-cards">
                  {items.map(p => <ProjectCard key={p.id} project={p} />)}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {view !== 'board' && (
        <div className="card" style={{ textAlign: 'center', padding: 60, color: '#98a0ad' }}>
          <div style={{ marginBottom: 12 }}>
            <Icon name={view === 'list' ? 'list' : 'bar-chart-horizontal'} size={36} strokeWidth={1.5} color="#cbd5e1" />
          </div>
          <div style={{ fontSize: 14, fontWeight: 600, color: '#4b5563' }}>{view === 'list' ? 'List' : 'Timeline'} view</div>
          <div style={{ fontSize: 12.5, marginTop: 4 }}>Switch back to Board to see the demo.</div>
        </div>
      )}
    </section>
  );
}

window.Projects = Projects;
