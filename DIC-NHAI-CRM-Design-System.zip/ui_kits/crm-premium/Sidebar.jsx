/* Sidebar.jsx — Linear/Stripe-style left rail with React Icon component */

function Sidebar({ activeTab, onTabChange, user, counts }) {
  const sections = [
    {
      title: 'Workspace',
      items: [
        { key: 'Dashboard', icon: 'layout-dashboard' },
        { key: 'Inbox',     icon: 'inbox', count: counts.inbox },
      ],
    },
    {
      title: 'Pipeline',
      items: [
        { key: 'Accounts', icon: 'users',     count: counts.accounts },
        { key: 'Deals',    icon: 'trending-up' },
        { key: 'Projects', icon: 'folder-kanban' },
      ],
    },
    {
      title: 'Operations',
      items: [
        { key: 'Support',   icon: 'life-buoy', count: counts.tickets },
        { key: 'Calendar',  icon: 'calendar' },
        { key: 'Reports',   icon: 'bar-chart-3' },
        { key: 'Documents', icon: 'file-text' },
      ],
    },
    {
      title: 'Admin',
      items: [
        { key: 'Settings', icon: 'settings' },
      ],
    },
  ];

  return (
    <aside className="sidebar" data-screen-label="Sidebar">
      <div className="sb-brand">
        <div className="sb-mark">D</div>
        <div className="sb-org">
          <div className="sb-org-name">DIC — NHAI</div>
          <div className="sb-org-sub">Command Centre</div>
        </div>
      </div>

      {sections.map(section => (
        <React.Fragment key={section.title}>
          <div className="sb-section">{section.title}</div>
          <nav className="sb-nav">
            {section.items.map(item => {
              const isActive = activeTab === item.key;
              return (
                <button
                  key={item.key}
                  className={'sb-item' + (isActive ? ' active' : '')}
                  onClick={() => onTabChange(item.key)}
                  style={{
                    background: isActive ? '#0a1628' : 'transparent',
                    color: isActive ? '#ffffff' : '#4b5563',
                    boxShadow: isActive ? '0 1px 3px rgba(10, 22, 40, .15)' : 'none',
                  }}
                >
                  <Icon name={item.icon} size={16} color={isActive ? '#f0c060' : '#98a0ad'} />
                  <span>{item.key}</span>
                  {item.count != null && (
                    <span className="count" style={{
                      background: isActive ? 'rgba(255,255,255,.12)' : '#f1f2f4',
                      color: isActive ? 'rgba(255,255,255,.7)' : '#98a0ad',
                    }}>{item.count}</span>
                  )}
                </button>
              );
            })}
          </nav>
        </React.Fragment>
      ))}

      <div className="sb-footer">
        <div className="sb-avatar">{user.initials}</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="sb-uname">{user.name}</div>
          <div className="sb-urole">{user.role}</div>
        </div>
        <Icon name="chevrons-up-down" size={14} color="#98a0ad" />
      </div>
    </aside>
  );
}

window.Sidebar = Sidebar;
