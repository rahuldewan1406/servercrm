/* Mock data for the DIC-NHAI CRM UI kit demo.
   All names, companies, amounts are fictional, India/NHAI-flavoured. */
window.crmData = {
  user: { name: 'Rajiv Kapoor', initials: 'R', role: 'Admin', email: 'rajiv.kapoor@nhai.gov.in' },

  kpis: [
    { id: 'contacts',  icon: '👥', val: '142', label: 'Total Contacts',   tone: 'blue'   },
    { id: 'leads',     icon: '🔥', val: '38',  label: 'Active Leads',     tone: 'violet' },
    { id: 'opps',      icon: '💰', val: '12',  label: 'Opportunities',    tone: 'green'  },
    { id: 'tickets',   icon: '🎫', val: '9',   label: 'Open Tickets',     tone: 'amber'  },
    { id: 'projects',  icon: '📁', val: '17',  label: 'Active Projects',  tone: 'teal'   },
    { id: 'renewals',  icon: '📅', val: '5',   label: 'Renewals (30d)',   tone: 'rose'   },
  ],

  pipeline: [
    { stage: 'New',       val: 4200000,  pct: 18, color: '#94a3b8' },
    { stage: 'Qualified', val: 8550000,  pct: 36, color: '#7c3aed' },
    { stage: 'Proposal',  val: 6800000,  pct: 29, color: '#d97706' },
    { stage: 'Won',       val: 9700000,  pct: 41, color: '#16a34a' },
    { stage: 'Lost',      val: 2400000,  pct: 10, color: '#e11d48' },
  ],

  ticketStatus: [
    { label: 'Open',        value: 9, color: '#d97706' },
    { label: 'In Progress', value: 6, color: '#2563eb' },
    { label: 'Resolved',    value: 24, color: '#16a34a' },
  ],

  funnel: [
    { label: 'Visitors',  count: 1280, pct: 100 },
    { label: 'Leads',     count:  420, pct: 33  },
    { label: 'Qualified', count:  180, pct: 14  },
    { label: 'Proposal',  count:   72, pct: 6   },
    { label: 'Won',       count:   28, pct: 2   },
  ],

  workload: [
    { name: 'S. Iyer',       count: 14, color: '#2563eb' },
    { name: 'R. Kapoor',     count: 11, color: '#7c3aed' },
    { name: 'A. Vasudevan',  count:  9, color: '#0d9488' },
    { name: 'P. Singh',      count:  7, color: '#d97706' },
    { name: 'M. Patel',      count:  4, color: '#16a34a' },
  ],

  topAccounts: [
    { name: 'NHAI HQ — Dwarka',    renewal: '14-Jun-2026', soon: true  },
    { name: 'PWD Rajasthan',       renewal: '02-Aug-2026', soon: false },
    { name: 'L&T Infrastructure',  renewal: '21-Jun-2026', soon: true  },
    { name: 'Tata Projects',       renewal: '11-Sep-2026', soon: false },
  ],

  activity: [
    { icon: '📞', text: 'Call logged with Mehul Patel — Tata Projects', time: '12m ago' },
    { icon: '📧', text: 'Bulk email sent to 24 contacts (Toll Plaza proposal)', time: '1h ago' },
    { icon: '💰', text: 'Opportunity "NH-8 Median upgrade" moved to Won', time: '3h ago' },
    { icon: '🎫', text: 'Ticket #TKT-4821 reassigned to A. Vasudevan',  time: '5h ago' },
    { icon: '📁', text: 'Project "FASTag retrofit batch" set to On Hold',time: '1d ago' },
    { icon: '👥', text: '3 contacts imported from CSV (NHAI Lucknow)',   time: '2d ago' },
  ],

  contacts: [
    { id: 1, name: 'Rajiv Kapoor',  company: 'Acme Highways Pvt Ltd', email: 'rajiv.kapoor@acmehw.in', phone: '+91 98100 22451', location: 'Gurugram, HR', tags: ['decision-maker','tier-1'], last: '3d', health: 'online',  initials: 'RK' },
    { id: 2, name: 'Mehul Patel',   company: 'Tata Projects',          email: 'mehul.patel@tataprojects.in', phone: '+91 98200 11242', location: 'Mumbai, MH',   tags: ['contract','renewal-q3'], last: '1w', health: 'online',  initials: 'MP' },
    { id: 3, name: 'Priya Singh',   company: 'L&T Infrastructure',     email: 'priya.s@lntinfra.in',     phone: '+91 98220 88110', location: 'Chennai, TN',  tags: ['tier-1'],                last: '2d', health: 'warning', initials: 'PS' },
    { id: 4, name: 'A. Vasudevan',  company: 'IHMCL',                  email: 'ashok@ihmcl.co.in',       phone: '+91 99720 41555', location: 'Delhi, DL',    tags: ['fastag'],                last: '5d', health: 'online',  initials: 'AV' },
    { id: 5, name: 'Kavita Rao',    company: 'PWD Rajasthan',          email: 'kavita.rao@pwdraj.gov.in',phone: '+91 99100 27744', location: 'Jaipur, RJ',   tags: ['government','tender'],   last: '1d', health: 'online',  initials: 'KR' },
    { id: 6, name: 'S. Iyer',       company: 'NHAI Lucknow Regional',  email: 's.iyer@nhai.gov.in',      phone: '+91 95000 44120', location: 'Lucknow, UP',  tags: ['gov','tier-1'],          last: '6h', health: 'online',  initials: 'SI' },
  ],

  accounts: [
    { id: 1, name: 'NHAI HQ — Dwarka',         meta: 'Gov · Tier 1 · 14 contacts', renewal: '14-Jun-2026', soon: true,  status: 'Active'   },
    { id: 2, name: 'L&T Infrastructure',       meta: 'Enterprise · Tier 1 · 22 contacts', renewal: '21-Jun-2026', soon: true,  status: 'Active'   },
    { id: 3, name: 'Tata Projects',            meta: 'Enterprise · Tier 1 · 18 contacts', renewal: '11-Sep-2026', soon: false, status: 'Active'   },
    { id: 4, name: 'PWD Rajasthan',            meta: 'Gov · Tier 2 · 9 contacts',  renewal: '02-Aug-2026', soon: false, status: 'Active'   },
    { id: 5, name: 'IHMCL',                    meta: 'PSU · Tier 1 · 11 contacts', renewal: '30-Oct-2026', soon: false, status: 'Active'   },
    { id: 6, name: 'Acme Highways Pvt Ltd',    meta: 'SMB · Tier 3 · 6 contacts',  renewal: '09-Dec-2026', soon: false, status: 'Planning' },
  ],

  leads: {
    New:       [{ id: 'L-401', title: 'Toll plaza tender',  val: '₹ 4.2M',  contact: 'Surat regional' }, { id: 'L-402', title: 'Smart corridor', val: '₹ 12.0M', contact: 'A. Vasudevan' }],
    Qualified: [{ id: 'L-403', title: 'NH-8 expansion',     val: '₹ 28.5M', contact: 'PWD Rajasthan' }, { id: 'L-404', title: 'Drone survey AMC', val: '₹ 2.4M', contact: 'NHAI Lucknow' }],
    Proposal:  [{ id: 'L-405', title: 'Median lighting',    val: '₹ 6.8M',  contact: 'NHAI Lucknow'  }, { id: 'L-406', title: 'FASTag retrofit', val: '₹ 3.1M', contact: 'IHMCL' }],
    Won:       [{ id: 'L-407', title: 'Side-barrier batch 4', val: '₹ 9.7M', contact: 'Closed 14-May' }],
    Lost:      [{ id: 'L-408', title: 'Crash-cushion AMC',  val: '₹ 1.2M',  contact: 'No budget'     }],
  },

  projects: {
    Planning:  [{ id: 'P-301', name: 'Toll plaza A-12',           manager: 'R. Kapoor',    due: '12-Aug-2026', progress: 12, account: 'NHAI HQ' }],
    Active:    [{ id: 'P-302', name: 'NH-8 Median upgrade',       manager: 'S. Iyer',      due: '30-Jul-2026', progress: 68, account: 'PWD Rajasthan' }, { id: 'P-303', name: 'Smart corridor pilot', manager: 'A. Vasudevan', due: '15-Sep-2026', progress: 42, account: 'NHAI HQ' }],
    OnHold:    [{ id: 'P-304', name: 'FASTag retrofit batch',     manager: 'P. Singh',     due: '—',           progress: 42, account: 'IHMCL' }],
    Completed: [{ id: 'P-305', name: 'Side-barrier batch 4',      manager: 'M. Patel',     due: '14-May-2026', progress: 100, account: 'L&T Infra' }],
  },

  tickets: [
    { id: 'TKT-4821', title: 'SMTP relay failing for bulk emails',   priority: 'High',   status: 'Open',        assignee: 'A. Vasudevan', meta: 'NHAI HQ · opened 2h ago' },
    { id: 'TKT-4820', title: 'C360° drawer not loading on Safari',   priority: 'Medium', status: 'In Progress', assignee: 'S. Iyer',      meta: 'L&T · opened yesterday' },
    { id: 'TKT-4819', title: 'CSV import column mismatch',           priority: 'Low',    status: 'In Progress', assignee: 'P. Singh',     meta: 'PWD Rajasthan · 3d' },
    { id: 'TKT-4818', title: 'Jira sync timeouts',                   priority: 'High',   status: 'Open',        assignee: 'R. Kapoor',    meta: 'NHAI Lucknow · 6h ago' },
    { id: 'TKT-4817', title: 'Renewal email template typo',          priority: 'Low',    status: 'Resolved',    assignee: 'M. Patel',     meta: 'Closed 1d ago' },
  ],
};
