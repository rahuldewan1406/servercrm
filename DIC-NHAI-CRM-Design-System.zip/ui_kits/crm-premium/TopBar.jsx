/* TopBar.jsx — slim search-forward bar (Apple Spotlight pattern) */

function TopBar() {
  return (
    <header className="topbar">
      <div className="search">
        <Icon name="search" size={15} color="#98a0ad" />
        <input placeholder="Search accounts, deals, projects, tickets…" />
        <kbd>⌘K</kbd>
      </div>
      <div className="topbar-actions">
        <button className="icon-btn" title="Help"><Icon name="help-circle" /></button>
        <span className="icon-btn-wrap">
          <button className="icon-btn" title="Notifications"><Icon name="bell" /></button>
          <span className="dot"></span>
        </span>
        <button className="icon-btn" title="Messages"><Icon name="message-square" /></button>
      </div>
    </header>
  );
}

window.TopBar = TopBar;
