# DIC-NHAI CRM · UI Kit (Premium)

Apple / Airbnb / Stripe-quality reinterpretation of the CRM. Sister to `../crm/` (the source-faithful recreation).

## Open
`index.html`

## Surfaces (all interactive)
- **Login** — refined NHAI brand surface (navy + gold + Playfair)
- **Dashboard** — Stripe-style KPIs + pipeline + donut + activity feed
- **Accounts** — Linear-style contact list + Airbnb-style account cards + Customer 360° drawer
- **Projects** — soft kanban with stacked-avatar cards, view toggle
- **Support** — premium ticket table with pill-status badges + filter tabs

## What's new vs `../crm/`
- Left sidebar nav (Workspace / Pipeline / Operations / Admin)
- **Lucide icons** everywhere — no emoji
- Soft tinted KPI icon chips, no left stripes
- `⌘K` search bar (Apple Spotlight)
- 32 px workspace padding, 28 px H1, more breathing room
- Hover lifts via soft shadow (`0 4px 16px rgba(10,22,40,.06)`), not border darkening

## Files
- `index.html` — entry point
- `styles.css` — premium-direction styling (uses tokens from `../../colors_and_type.css`)
- `data.js` — shared mock data
- `Login.jsx`, `Sidebar.jsx`, `TopBar.jsx`, `Dashboard.jsx`, `Accounts.jsx`, `Projects.jsx`, `Support.jsx`

## Stack
React 18 (UMD) · Babel standalone · Lucide UMD. No build step.
