/* Icon.jsx — React-native Lucide icon component.
   Reads from window.lucide.icons (the icon node array) and emits SVG via
   JSX so React owns the DOM. No createIcons() document-wide mutation. */

function Icon({ name, size = 16, color = 'currentColor', strokeWidth = 1.75, style }) {
  const icons = window.lucide && window.lucide.icons;
  if (!icons) return null;

  // kebab-case → PascalCase (e.g. layout-dashboard → LayoutDashboard)
  const key = name.split('-')
    .map(p => p ? p[0].toUpperCase() + p.slice(1) : '')
    .join('');
  let node = icons[key];
  if (!node) {
    return <span style={{ display: 'inline-block', width: size, height: size }} />;
  }

  // lucide UMD wraps each icon as { iconNode: [...], ... } in newer versions,
  // and as a plain [...] array in older ones. Normalise.
  if (node && !Array.isArray(node) && node.iconNode) node = node.iconNode;
  // Some bundles also expose [name, attrs, iconNodeArray] — unwrap last position
  if (Array.isArray(node) && node.length === 3 && typeof node[0] === 'string' && Array.isArray(node[2])) {
    node = node[2];
  }
  if (!Array.isArray(node)) {
    return <span style={{ display: 'inline-block', width: size, height: size }} />;
  }

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      style={{ display: 'inline-block', verticalAlign: 'middle', flexShrink: 0, ...style }}
    >
      {node.map((entry, i) => {
        if (!Array.isArray(entry) || entry.length < 2) return null;
        const [tag, attrs] = entry;
        if (typeof tag !== 'string' || !attrs || typeof attrs !== 'object') return null;
        const reactAttrs = { key: i };
        for (const k in attrs) {
          const reactKey = k.replace(/-([a-z])/g, (_, c) => c.toUpperCase());
          reactAttrs[reactKey] = attrs[k];
        }
        return React.createElement(tag, reactAttrs);
      })}
    </svg>
  );
}

window.Icon = Icon;
