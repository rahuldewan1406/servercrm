/* Accounts.jsx — React Icon component (no DOM mutation) */

const avatarColors = [
  ['#2563eb', '#7c3aed'],
  ['#0d9488', '#2563eb'],
  ['#d97706', '#e11d48'],
  ['#16a34a', '#0d9488'],
  ['#7c3aed', '#e11d48'],
  ['#1d4ed8', '#0d9488'],
];

function initialsOf(str) {
  return str.split(/[\s—\-]+/).filter(Boolean).slice(0, 2).map(w => w[0]).join('').slice(0, 2).toUpperCase();
}

function ContactRow({ contact, onClick }) {
  const [g1, g2] = avatarColors[(contact.id - 1) % avatarColors.length];
  const tagTone = tag => {
    if (tag.includes('tier-1') || tag === 'decision-maker') return 'accent';
    if (tag === 'government' || tag === 'gov') return 'green';
    if (tag === 'renewal-q3' || tag === 'tender') return 'amber';
    return '';
  };
  return (
    <div className="contact-row" onClick={onClick}>
      <div className="contact-avatar" style={{ background: `linear-gradient(135deg, ${g1}, ${g2})` }}>
        {contact.initials}
      </div>
      <div className="cell-primary">
        <span className={'health-dot health-' + (contact.health === 'online' ? 'online' : 'warn')}></span>
        {contact.name}
        <div className="sub">{contact.company}</div>
      </div>
      <div className="cell-secondary">
        {contact.email}
        <div style={{ fontSize: 11.5, color: '#98a0ad', marginTop: 1, fontFamily: 'DM Mono, monospace' }}>{contact.phone}</div>
      </div>
      <div className="tag-row">
        {contact.tags.slice(0, 2).map(t => (
          <span key={t} className={'tag ' + tagTone(t)}>{t}</span>
        ))}
      </div>
      <div className="cell-mono">{contact.last} ago</div>
      <div className="row-actions" onClick={e => e.stopPropagation()}>
        <button className="row-icon-btn" title="Email"><Icon name="mail" size={15} /></button>
        <button className="row-icon-btn" title="Edit"><Icon name="pencil" size={15} /></button>
        <button className="row-icon-btn" title="More"><Icon name="more-horizontal" size={15} /></button>
      </div>
    </div>
  );
}

function AcctCard({ account }) {
  return (
    <article className="acct-card">
      <div className="acct-head">
        <div className="acct-mono">{initialsOf(account.name)}</div>
        <div className="acct-title">
          <div className="acct-name">{account.name}</div>
          <div className="acct-meta">{account.meta}</div>
        </div>
        <span className={'badge b-' + account.status.toLowerCase()}>
          <span className="badge-pin"></span>{account.status}
        </span>
      </div>
      <div className="acct-stats">
        <div className="acct-stat"><div className="acct-stat-val">₹4.2M</div><div className="acct-stat-lbl">Lifetime</div></div>
        <div className="acct-stat"><div className="acct-stat-val">8</div><div className="acct-stat-lbl">Open deals</div></div>
        <div className="acct-stat"><div className="acct-stat-val">14</div><div className="acct-stat-lbl">Contacts</div></div>
      </div>
      <div className="acct-foot">
        <span className="acct-renew-label">Renewal due</span>
        <span className={'acct-renew-date' + (account.soon ? ' soon' : '')}>{account.renewal}</span>
      </div>
    </article>
  );
}

function Customer360({ contact, onClose }) {
  const [tab, setTab] = React.useState('overview');
  if (!contact) return null;
  const [g1, g2] = avatarColors[(contact.id - 1) % avatarColors.length];

  return (
    <div className="drawer-overlay" onClick={onClose}>
      <div className="drawer" onClick={e => e.stopPropagation()}>
        <div className="drawer-head">
          <button className="drawer-close" onClick={onClose}><Icon name="x" size={16} /></button>
          <div className="drawer-avatar" style={{ background: `linear-gradient(135deg, ${g1}, ${g2})` }}>
            {contact.initials}
          </div>
          <div style={{ flex: 1 }}>
            <div className="drawer-name">{contact.name}</div>
            <div className="drawer-sub">{contact.company} · {contact.location}</div>
          </div>
          <div className="drawer-actions">
            <button className="drawer-close" title="Email"><Icon name="mail" size={15} /></button>
            <button className="drawer-close" title="Call"><Icon name="phone" size={15} /></button>
            <button className="drawer-close" title="More"><Icon name="more-horizontal" size={15} /></button>
          </div>
        </div>

        <div className="drawer-tabs">
          {['overview', 'activity', 'deals', 'tickets', 'docs'].map(t => (
            <button
              key={t}
              className={'drawer-tab' + (tab === t ? ' active' : '')}
              onClick={() => setTab(t)}
            >
              {t.charAt(0).toUpperCase() + t.slice(1)}
            </button>
          ))}
        </div>

        <div className="drawer-body">
          {tab === 'overview' && (
            <React.Fragment>
              <div className="drawer-stats">
                <div className="dstat">
                  <div className="dstat-val">₹4.2M</div>
                  <div className="dstat-lbl">Lifetime value</div>
                  <div className="dstat-delta">↑ 18% YoY</div>
                </div>
                <div className="dstat">
                  <div className="dstat-val">8</div>
                  <div className="dstat-lbl">Open deals</div>
                  <div className="dstat-delta">↑ 2 this month</div>
                </div>
                <div className="dstat">
                  <div className="dstat-val">12</div>
                  <div className="dstat-lbl">Tickets</div>
                  <div className="dstat-delta" style={{ color: '#98a0ad' }}>3 open</div>
                </div>
              </div>

              <div className="drawer-section-h">Details</div>
              <div className="dgrid">
                <div className="dgrid-item"><div className="k">Email</div><div className="v">{contact.email}</div></div>
                <div className="dgrid-item"><div className="k">Phone</div><div className="v">{contact.phone}</div></div>
                <div className="dgrid-item"><div className="k">Location</div><div className="v">{contact.location}</div></div>
                <div className="dgrid-item"><div className="k">Last contact</div><div className="v">{contact.last} ago</div></div>
                <div className="dgrid-item"><div className="k">Owner</div><div className="v">Rajiv Kapoor</div></div>
                <div className="dgrid-item"><div className="k">Source</div><div className="v">Referral</div></div>
              </div>

              <div className="drawer-section-h">Tags</div>
              <div className="tag-row">
                {contact.tags.map(t => <span key={t} className="tag accent">{t}</span>)}
              </div>

              <div className="drawer-section-h">Recent activity</div>
              <div className="activity">
                {[
                  { icon: 'phone',       text: 'Call logged — discussed NH-8 expansion timeline', time: '12m ago' },
                  { icon: 'mail',        text: 'Email: "Re: Toll plaza specs v3"',                time: '1h ago' },
                  { icon: 'trending-up', text: 'Deal moved to Proposal',                          time: '6h ago' },
                ].map((a, i) => (
                  <div key={i} className="activity-item" style={{ padding: '10px 0' }}>
                    <div className="activity-icon"><Icon name={a.icon} size={14} /></div>
                    <div className="activity-body">
                      <div className="activity-text">{a.text}</div>
                      <div className="activity-time">{a.time}</div>
                    </div>
                  </div>
                ))}
              </div>
            </React.Fragment>
          )}
          {tab !== 'overview' && (
            <div style={{ padding: 60, textAlign: 'center', color: '#98a0ad' }}>
              <div style={{ marginBottom: 12 }}><Icon name="inbox" size={36} strokeWidth={1.5} color="#cbd5e1" /></div>
              <div style={{ fontSize: 14, fontWeight: 600, color: '#4b5563' }}>No {tab} yet</div>
              <div style={{ fontSize: 12.5, marginTop: 4 }}>This contact has no {tab} records.</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function Accounts({ data }) {
  const [query, setQuery]   = React.useState('');
  const [active, setActive] = React.useState(null);

  const filtered = data.contacts.filter(c =>
    !query ||
    c.name.toLowerCase().includes(query.toLowerCase()) ||
    c.company.toLowerCase().includes(query.toLowerCase()) ||
    c.location.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <section data-screen-label="Accounts">
      <div className="page-header">
        <div>
          <h1>Accounts &amp; contacts</h1>
          <div className="sub">{data.contacts.length} contacts · {data.accounts.length} accounts</div>
        </div>
        <div className="page-actions">
          <button className="btn btn-secondary"><Icon name="upload" />Import</button>
          <button className="btn btn-primary"><Icon name="plus" />New contact</button>
        </div>
      </div>

      <div className="contacts-toolbar">
        <div className="cf-search">
          <Icon name="search" size={15} color="#98a0ad" />
          <input
            placeholder="Search by name, email, company, location…"
            value={query}
            onChange={e => setQuery(e.target.value)}
          />
        </div>
        <div className="cf-filters">
          <button className="filter-chip"><Icon name="building-2" size={14} />Company</button>
          <button className="filter-chip"><Icon name="map-pin" size={14} />Location</button>
          <button className="filter-chip"><Icon name="tag" size={14} />Tag</button>
          <button className="filter-chip"><Icon name="sliders-horizontal" size={14} />Filters</button>
        </div>
      </div>

      <div className="contact-list">
        <div className="contact-row head">
          <span></span>
          <span>Contact</span>
          <span>Email / phone</span>
          <span>Tags</span>
          <span>Last touch</span>
          <span></span>
        </div>
        {filtered.map(c => (
          <ContactRow key={c.id} contact={c} onClick={() => setActive(c)} />
        ))}
      </div>

      <div className="accounts-section">
        <div className="section-h2">
          Accounts
          <button className="btn btn-ghost"><Icon name="external-link" />View all</button>
        </div>
        <div className="account-cards">
          {data.accounts.map(a => <AcctCard key={a.id} account={a} />)}
        </div>
      </div>

      {active && <Customer360 contact={active} onClose={() => setActive(null)} />}
    </section>
  );
}

window.Accounts = Accounts;
