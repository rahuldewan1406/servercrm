/* Support.jsx — premium ticket table with React Icon */

function assigneeInitials(name) {
  return name.split(/[.\s]+/).filter(Boolean).map(w => w[0]).join('').slice(0, 2).toUpperCase();
}

function Support({ data }) {
  const [filter, setFilter] = React.useState('all');

  const counts = {
    all:        data.tickets.length,
    open:       data.tickets.filter(t => t.status === 'Open').length,
    inprogress: data.tickets.filter(t => t.status === 'In Progress').length,
    resolved:   data.tickets.filter(t => t.status === 'Resolved').length,
  };
  const visible = filter === 'all'
    ? data.tickets
    : data.tickets.filter(t => t.status.toLowerCase().replace(/\s/g, '') === filter);

  const statusClass = s => 'b-' + s.toLowerCase().replace(/\s/g, '').replace('inprogress', 'progress');

  return (
    <section data-screen-label="Support">
      <div className="page-header">
        <div>
          <h1>Support</h1>
          <div className="sub">{counts.open} open · {counts.inprogress} in progress · SLA on track</div>
        </div>
        <div className="page-actions">
          <button className="btn btn-secondary"><Icon name="download" />Export</button>
          <button className="btn btn-primary"><Icon name="plus" />New ticket</button>
        </div>
      </div>

      <div className="kpi-row">
        <div className="kpi">
          <div className="kpi-top">
            <div className="kpi-chip chip-amber"><Icon name="circle-dot" size={18} strokeWidth={2} /></div>
            <span className="kpi-delta delta-up"><Icon name="arrow-up-right" size={11} strokeWidth={2.2} />+2</span>
          </div>
          <div className="kpi-val">{counts.open}</div>
          <div className="kpi-label">Open</div>
        </div>
        <div className="kpi">
          <div className="kpi-top">
            <div className="kpi-chip chip-blue"><Icon name="clock" size={18} strokeWidth={2} /></div>
            <span className="kpi-delta delta-flat"><Icon name="minus" size={11} strokeWidth={2.2} />—</span>
          </div>
          <div className="kpi-val">{counts.inprogress}</div>
          <div className="kpi-label">In progress</div>
        </div>
        <div className="kpi">
          <div className="kpi-top">
            <div className="kpi-chip chip-green"><Icon name="check-circle-2" size={18} strokeWidth={2} /></div>
            <span className="kpi-delta delta-up"><Icon name="arrow-up-right" size={11} strokeWidth={2.2} />+14</span>
          </div>
          <div className="kpi-val">{counts.resolved}</div>
          <div className="kpi-label">Resolved · 7d</div>
        </div>
        <div className="kpi">
          <div className="kpi-top">
            <div className="kpi-chip chip-rose"><Icon name="alert-triangle" size={18} strokeWidth={2} /></div>
          </div>
          <div className="kpi-val">32m</div>
          <div className="kpi-label">Avg first response</div>
        </div>
      </div>

      <div className="kanban-header" style={{ marginBottom: 16 }}>
        <div className="view-tabs">
          {[
            { k: 'all',        l: 'All' },
            { k: 'open',       l: 'Open' },
            { k: 'inprogress', l: 'In progress' },
            { k: 'resolved',   l: 'Resolved' },
          ].map(t => (
            <button
              key={t.k}
              className={'view-tab' + (filter === t.k ? ' active' : '')}
              onClick={() => setFilter(t.k)}
            >
              {t.l} <span style={{ color: '#98a0ad', fontFamily: 'DM Mono, monospace', fontSize: 11, marginLeft: 4 }}>{counts[t.k]}</span>
            </button>
          ))}
        </div>
        <button className="btn btn-ghost"><Icon name="sliders-horizontal" />Sort</button>
      </div>

      <div className="ticket-table">
        <div className="ticket-row head">
          <span>ID</span>
          <span>Subject</span>
          <span>Assignee</span>
          <span>Priority</span>
          <span>Status</span>
        </div>
        {visible.map(t => (
          <div key={t.id} className="ticket-row">
            <span className="ticket-id">{t.id}</span>
            <div>
              <div className="ticket-title">{t.title}</div>
              <div className="ticket-title sub">{t.meta}</div>
            </div>
            <div className="assignee">
              <span className="a">{assigneeInitials(t.assignee)}</span>
              {t.assignee}
            </div>
            <span className={'badge b-' + t.priority.toLowerCase()}>
              <span className="badge-pin"></span>{t.priority}
            </span>
            <span className={'badge ' + statusClass(t.status)}>
              <span className="badge-pin"></span>{t.status}
            </span>
          </div>
        ))}
      </div>
    </section>
  );
}

window.Support = Support;
